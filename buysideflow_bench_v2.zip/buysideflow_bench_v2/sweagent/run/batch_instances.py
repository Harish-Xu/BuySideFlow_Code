import json
import random
import re
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from swerex.deployment.config import (
    DeploymentConfig,
    DockerDeploymentConfig,
    DummyDeploymentConfig,
    LocalDeploymentConfig,
)
from typing_extensions import Self

from sweagent.agent.problem_statement import (
    ProblemStatementConfig,
    SWEBenchMultimodalProblemStatement,
    Text2SQLProblemStatement,
    TextProblemStatement,
)
from sweagent.environment.repo import GithubRepoConfig, LocalRepoConfig, PreExistingRepoConfig
from sweagent.environment.swe_env import EnvironmentConfig
from sweagent.text2sql.defaults import (
    DEFAULT_BACKGROUND_PATH,
    DEFAULT_BOND_RULES_PATH,
    DEFAULT_CATALOG_SCHEMA_PATH,
    DEFAULT_FUND_RULES_PATH,
    DEFAULT_SCHEMA_PATH,
    DEFAULT_SELECTION_GUIDANCE_PATH,
)
from sweagent.text2sql.markdown import parse_text2sql_tasks
from sweagent.text2sql.schema import (
    infer_business_rule_domains,
    match_requested_tables,
    render_business_background,
    render_domain_rules,
    render_focused_schema_catalog,
    render_schema_catalog,
    render_schema_table_index,
    render_table_name_list,
    render_text_asset,
)
from sweagent.utils.files import load_file
from sweagent.utils.log import get_logger

logger = get_logger("swea-config", emoji="🔧")


class AbstractInstanceSource(ABC):
    """Anything that adheres to this standard can be used to load instances."""

    @abstractmethod
    def get_instance_configs(self) -> list[EnvironmentConfig]: ...


class BatchInstance(BaseModel):
    """A single instance in a batch of instances.
    This specifies both the environment configuration and the problem statement.
    """

    env: EnvironmentConfig
    problem_statement: ProblemStatementConfig


def _slice_spec_to_slice(slice_spec: str) -> slice:
    if slice_spec == "":
        return slice(None)
    parts = slice_spec.split(":")
    values = [None if p == "" else int(p) for p in parts]
    if len(parts) == 1:
        return slice(values[0])
    if len(parts) == 2:
        return slice(values[0], values[1])
    if len(parts) == 3:
        return slice(values[0], values[1], values[2])
    msg = (
        f"Invalid slice specification: {slice_spec!r}. "
        "Here's the expected format: stop or start:stop or start:stop:step "
        "(i.e., it behaves exactly like python's list slicing `list[slice]`)."
    )
    raise ValueError(msg)


def _filter_batch_items(
    instances: list[BatchInstance], *, filter_: str, slice_: str = "", shuffle: bool = False
) -> list[BatchInstance]:
    if shuffle:
        instances = sorted(instances.copy(), key=lambda x: x.problem_statement.id)
        random.seed(42)
        random.shuffle(instances)
    before_filter = len(instances)
    instances = [instance for instance in instances if re.match(filter_, instance.problem_statement.id)]
    after_filter = len(instances)
    if before_filter != after_filter:
        logger.info("Instance filter: %d -> %d instances", before_filter, after_filter)
    if slice_:
        instances = instances[_slice_spec_to_slice(slice_)]
        after_slice = len(instances)
        if before_filter != after_slice:
            logger.info("Instance slice: %d -> %d instances", before_filter, after_slice)
    return instances


class SimpleBatchInstance(BaseModel):
    """A simple way to configure a single instance in a batch of instances that all
    use similar deployment configurations.

    Predominantly used for benchmarking purposes. Assumes that the repository is already
    present in the docker container.
    """

    image_name: str
    problem_statement: str
    instance_id: str
    repo_name: str = ""
    """Specifies the repository to use. If empty, no repository is used.
    If the string does not contain a slash, it is interpreted as an already existing repository at the root
    of the docker container. If it contains the word "github", it is interpreted as a github repository.
    Else, it is interpreted as a local repository.
    """
    base_commit: str = "HEAD"
    """Used to reset repo."""
    extra_fields: dict[str, Any] = Field(default_factory=dict)
    """Any additional data to be added to the instance.
    This data will be available when formatting prompt templates.
    """

    # Ignore instead of allow because they should be added as `extra_fields`
    model_config = ConfigDict(extra="ignore")

    def to_full_batch_instance(self, deployment: DeploymentConfig) -> BatchInstance:
        """Merge the deployment options into the `SimpleBatchInstance` object to get a full `BatchInstance`."""
        # Very important: Make a copy of the deployment config because it will be shared among instances!!!
        deployment = deployment.model_copy(deep=True)

        if "issue_images" in self.extra_fields:
            problem_statement = SWEBenchMultimodalProblemStatement(
                text=self.problem_statement,
                issue_images=self.extra_fields.pop("issue_images"),
                id=self.instance_id,
                extra_fields=self.extra_fields,
            )
        else:
            problem_statement = TextProblemStatement(
                text=self.problem_statement, id=self.instance_id, extra_fields=self.extra_fields
            )

        if not self.repo_name:
            repo = None
        elif "github" in self.repo_name:
            repo = GithubRepoConfig(github_url=self.repo_name, base_commit=self.base_commit)
        elif "/" not in self.repo_name:
            repo = PreExistingRepoConfig(repo_name=self.repo_name, base_commit=self.base_commit)
        else:
            repo = LocalRepoConfig(path=Path(self.repo_name), base_commit=self.base_commit)
        if isinstance(deployment, LocalDeploymentConfig):
            if self.image_name:
                msg = "Local deployment does not support image_name"
                raise ValueError(msg)
            return BatchInstance(
                env=EnvironmentConfig(deployment=deployment, repo=repo), problem_statement=problem_statement
            )
        if isinstance(deployment, DummyDeploymentConfig):
            return BatchInstance(
                env=EnvironmentConfig(deployment=deployment, repo=repo), problem_statement=problem_statement
            )

        deployment.image = self.image_name  # type: ignore

        if isinstance(deployment, DockerDeploymentConfig) and deployment.python_standalone_dir is None:
            # Note: you can disable this by setting python_standalone_dir to ""
            deployment.python_standalone_dir = "/root"  # type: ignore

        return BatchInstance(
            env=EnvironmentConfig(deployment=deployment, repo=repo), problem_statement=problem_statement
        )

    @model_validator(mode="before")
    @classmethod
    def handle_legacy_id(cls, data):
        # Handling compatibility with swe-agent <= 1.0.1
        if isinstance(data, dict):
            if "id" in data and "instance_id" not in data:
                data["instance_id"] = data["id"]
                data.pop("id")
        return data

    # todo: Maybe populate extra fields?
    @classmethod
    def from_swe_bench(cls, instance: dict[str, Any]) -> Self:
        """Convert instances from the classical SWE-bench dataset to the `SimpleBatchInstance` format."""
        iid = instance["instance_id"]
        image_name = instance.get("image_name", None)
        if image_name is None:
            # Docker doesn't allow double underscore, so we replace them with a magic token
            id_docker_compatible = iid.replace("__", "_1776_")
            image_name = f"docker.io/swebench/sweb.eval.x86_64.{id_docker_compatible}:latest".lower()
        extra_fields = {}
        if "image_assets" in instance:
            issue_images = json.loads(instance["image_assets"])["problem_statement"]
            extra_fields["issue_images"] = issue_images
        return cls(
            image_name=image_name,
            problem_statement=instance["problem_statement"],
            instance_id=iid,
            repo_name="testbed",
            base_commit=instance["base_commit"],
            extra_fields=extra_fields,
        )


class InstancesFromFile(BaseModel, AbstractInstanceSource):
    """Load instances from a file."""

    path: Path
    filter: str = ".*"
    """Regular expression to filter the instances by instance id."""
    slice: str = ""
    """Select only a slice of the instances (after filtering by `filter`).
    Possible values are stop or start:stop or start:stop:step
    (i.e., it behaves exactly like python's list slicing `list[slice]`).
    """
    shuffle: bool = False
    """Shuffle the instances (before filtering and slicing)."""

    deployment: DeploymentConfig = Field(
        default_factory=lambda: DockerDeploymentConfig(image="python:3.11"),
        description="Deployment options.",
    )
    """Note that the image_name option is overwritten by the images specified in the task instances."""

    simple: Literal[True] = True
    """Convenience discriminator for (de)serialization/CLI. Do not change."""

    type: Literal["file"] = "file"
    """Discriminator for (de)serialization/CLI. Do not change."""

    def get_instance_configs(self) -> list[BatchInstance]:
        instance_dicts = load_file(self.path)
        simple_instances = [SimpleBatchInstance.model_validate(instance_dict) for instance_dict in instance_dicts]
        instances = [instance.to_full_batch_instance(self.deployment) for instance in simple_instances]
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=self.shuffle)

    @property
    def id(self) -> str:
        return self.path.stem


class InstancesFromHuggingFace(BaseModel, AbstractInstanceSource):
    """Load instances from HuggingFace."""

    dataset_name: str
    """Name of the HuggingFace dataset. Same as when using `datasets.load_dataset`."""
    split: str = "dev"
    filter: str = ".*"
    """Regular expression to filter the instances by instance id."""
    slice: str = ""
    """Select only a slice of the instances (after filtering by `filter`).
    Possible values are stop or start:stop or start:stop:step.
    (i.e., it behaves exactly like python's list slicing `list[slice]`).
    """
    shuffle: bool = False
    """Shuffle the instances (before filtering and slicing)."""

    deployment: DeploymentConfig = Field(
        default_factory=lambda: DockerDeploymentConfig(image="python:3.11"),
    )
    """Deployment configuration. Note that the `image_name` option is overwritten by the images specified in the task instances.
    """
    type: Literal["huggingface"] = "huggingface"
    """Discriminator for (de)serialization/CLI. Do not change."""

    def get_instance_configs(self) -> list[BatchInstance]:
        from datasets import load_dataset

        ds: list[dict[str, Any]] = load_dataset(self.dataset_name, split=self.split)  # type: ignore
        simple_instances: list[SimpleBatchInstance] = [SimpleBatchInstance.model_validate(instance) for instance in ds]
        instances = [instance.to_full_batch_instance(self.deployment) for instance in simple_instances]
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=self.shuffle)

    @property
    def id(self) -> str:
        ds_name = "".join(l for l in self.dataset_name if l.isalnum() or l in ["-", "_"])
        return f"{ds_name}_{self.split}"


class SWEBenchInstances(BaseModel, AbstractInstanceSource):
    """Load instances from SWE-bench."""

    subset: Literal["lite", "verified", "full", "multimodal", "multilingual"] = "lite"
    """Subset of swe-bench to use"""

    # IMPORTANT: Do not call this `path`, because then if people do not specify instance.type,
    # it might be resolved to ExpertInstancesFromFile or something like that.
    path_override: str | Path | None = None
    """Allow to specify a different huggingface dataset name or path to a huggingface
    dataset. This will override the automatic path set by `subset`.
    """

    split: Literal["dev", "test"] = "dev"

    deployment: DeploymentConfig = Field(
        default_factory=lambda: DockerDeploymentConfig(image="python:3.11"),
    )
    """Deployment configuration. Note that the image_name option is overwritten by the images specified in the task instances.
    """

    type: Literal["swe_bench"] = "swe_bench"
    """Discriminator for (de)serialization/CLI. Do not change."""

    filter: str = ".*"
    """Regular expression to filter the instances by instance id."""
    slice: str = ""
    """Select only a slice of the instances (after filtering by `filter`).
    Possible values are stop or start:stop or start:stop:step.
    (i.e., it behaves exactly like python's list slicing `list[slice]`).
    """
    shuffle: bool = False
    """Shuffle the instances (before filtering and slicing)."""

    evaluate: bool = False
    """Run sb-cli to evaluate"""

    def _get_dataset_path(self) -> str:
        if self.path_override is not None:
            return str(self.path_override)
        dataset_mapping = {
            "full": "princeton-nlp/SWE-Bench",
            "verified": "princeton-nlp/SWE-Bench_Verified",
            "lite": "princeton-nlp/SWE-Bench_Lite",
            "multimodal": "princeton-nlp/SWE-Bench_Multimodal",
            "multilingual": "swe-bench/SWE-Bench_Multilingual",
        }

        if self.subset not in dataset_mapping:
            msg = f"Unsupported subset: {self.subset}"
            raise ValueError(msg)

        return dataset_mapping[self.subset]

    def get_instance_configs(self) -> list[BatchInstance]:
        from datasets import load_dataset

        ds: list[dict[str, Any]] = load_dataset(self._get_dataset_path(), split=self.split)  # type: ignore

        if isinstance(self.deployment, DockerDeploymentConfig):
            self.deployment.platform = "linux/amd64"

        instances = [
            SimpleBatchInstance.from_swe_bench(instance).to_full_batch_instance(self.deployment) for instance in ds
        ]
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=self.shuffle)

    @property
    def id(self) -> str:
        return f"swe_bench_{self.subset}_{self.split}"


class ExpertInstancesFromFile(BaseModel, AbstractInstanceSource):
    """Load instances from a file. The difference to `InstancesFromFile` is that the instances are configured as full
    `EnvironmentInstanceConfig` objects, i.e., we could specify separate deployment configurations etc.
    """

    path: Path
    filter: str = ".*"
    """Regular expression to filter the instances by instance id."""
    slice: str = ""
    """Select only a slice of the instances (after filtering by `filter`).
    Possible values are stop or start:stop or start:stop:step.
    (i.e., it behaves exactly like python's list slicing `list[slice]`).
    """
    shuffle: bool = False
    """Shuffle the instances (before filtering and slicing)."""

    type: Literal["expert_file"] = "expert_file"
    """Discriminator for (de)serialization/CLI. Do not change."""

    def get_instance_configs(self) -> list[BatchInstance]:
        instance_dicts = load_file(self.path)
        instances = [BatchInstance.model_validate(instance_dict) for instance_dict in instance_dicts]
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=self.shuffle)

    @property
    def id(self) -> str:
        return self.path.stem


class SWESmithInstances(BaseModel, AbstractInstanceSource):
    """Load instances from SWE-smith."""

    path: Path

    deployment: DeploymentConfig = Field(
        default_factory=lambda: DockerDeploymentConfig(image="python:3.11"),
    )
    """Deployment configuration. Note that the image_name option is overwritten by the images specified in the task instances.
    """

    filter: str = ".*"
    """Regular expression to filter the instances by instance id."""
    slice: str = ""
    """Select only a slice of the instances (after filtering by `filter`).
    Possible values are stop or start:stop or start:stop:step.
    (i.e., it behaves exactly like python's list slicing `list[slice]`).
    """
    shuffle: bool = False
    """Shuffle the instances (before filtering and slicing)."""

    type: Literal["swesmith"] = "swesmith"
    """Discriminator for (de)serialization/CLI. Do not change."""

    def get_instance_configs(self) -> list[BatchInstance]:
        def convert_instance_dict(instance_dict: dict[str, Any]) -> dict[str, Any]:
            instance_dict["id"] = instance_dict["instance_id"]
            # todo: The base_commit is currently incorrect
            instance_dict["base_commit"] = instance_dict["id"]
            instance_dict["problem_statement"] = instance_dict.get("problem_statement", "")
            instance_dict["repo_name"] = "testbed"
            instance_dict["extra_fields"] = {"fail_to_pass": instance_dict["FAIL_TO_PASS"]}
            return instance_dict

        instance_dicts = load_file(self.path)
        instances = [
            SimpleBatchInstance.model_validate(convert_instance_dict(instance_dict)).to_full_batch_instance(
                self.deployment
            )
            for instance_dict in instance_dicts
        ]
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=self.shuffle)

    @property
    def id(self) -> str:
        return f"swesmith_{self.path.stem}"


class Text2SQLInstances(BaseModel, AbstractInstanceSource):
    """从正式数据集目录或显式任务文件加载 Text-to-SQL 实例。

    JSON 格式::

        [
          {
            "id": "q1",
            "question": "筛选市盈率低于30...",
            "mode": "sql",
            "sql_code": "SELECT ...",
            "python_code": "",
            "result_vars": []
          },
          ...
        ]
    """

    path: Path
    """Benchmark dataset directory or an explicitly supplied task file."""

    schema_path: Path = Field(default=DEFAULT_SCHEMA_PATH, description="Path to the full schema JSON (used by request_schema tool).")
    catalog_schema_path: Path = Field(default=DEFAULT_CATALOG_SCHEMA_PATH, description="Path to the catalog schema JSON (shown upfront to model; core tables full columns, others slim).")

    business_metadata_path: Path | None = Field(
        default=DEFAULT_BACKGROUND_PATH,
        description="Optional prompt background text path.",
    )

    selection_guidance_path: Path | None = Field(
        default=DEFAULT_SELECTION_GUIDANCE_PATH,
        description="Optional schema selection guidance text path.",
    )

    fund_rules_path: Path | None = Field(
        default=DEFAULT_FUND_RULES_PATH,
        description="Optional fund-domain business rules text path.",
    )

    bond_rules_path: Path | None = Field(
        default=DEFAULT_BOND_RULES_PATH,
        description="Optional bond-domain business rules text path.",
    )

    filter: str = ".*"
    slice: str = ""
    shuffle: bool = False

    evaluate: bool = True
    """Whether to run our Text2SQL evaluator after all instances."""

    catalog_columns_per_table: int = 20
    schema_columns_per_table: int = 80

    deployment: DeploymentConfig = Field(
        default_factory=lambda: LocalDeploymentConfig(),
        description="Deployment options. Default: local (no Docker).",
    )

    type: Literal["text2sql"] = "text2sql"
    """Discriminator for (de)serialization/CLI. Do not change."""

    def _load_tasks(self) -> list[dict[str, Any]]:
        all_ids: list[str] = []

        def selected(task_id: str) -> bool:
            all_ids.append(task_id)
            return re.match(self.filter, task_id) is not None

        if self.path.is_dir() or self.path.suffix.lower() in {".md", ".markdown", ".jsonl"}:
            tasks = parse_text2sql_tasks(self.path, task_filter=selected)
        else:
            tasks = [
                task for task in load_file(self.path)
                if selected(str(task.get("id", task.get("instance_id", "unknown"))))
            ]
        if self.shuffle:
            # Preserve the original full-universe shuffle before filtering/slicing.
            all_ids.sort()
            random.Random(42).shuffle(all_ids)
            positions = {task_id: i for i, task_id in enumerate(all_ids)}
            tasks.sort(key=lambda task: positions[str(task.get("id", task.get("instance_id", "unknown")))])
        return tasks

    def get_instance_configs(self) -> list[BatchInstance]:
        task_list = self._load_tasks()
        default_schema_catalog = render_schema_catalog(
            self.catalog_schema_path, max_columns_per_table=self.catalog_columns_per_table
        )
        schema_table_index = render_schema_table_index(self.catalog_schema_path)
        table_name_list = render_table_name_list(self.catalog_schema_path)
        business_background = render_business_background(self.business_metadata_path)
        selection_guidance = render_text_asset(self.selection_guidance_path)
        fund_rules = render_text_asset(self.fund_rules_path)
        bond_rules = render_text_asset(self.bond_rules_path)

        instances: list[BatchInstance] = []
        for task in task_list:
            schema_tables, _ = match_requested_tables(
                self.catalog_schema_path,
                list(task.get("schema_tables", [])),
            )
            focused_schema_catalog = render_focused_schema_catalog(
                self.catalog_schema_path,
                schema_tables,
                max_columns_per_table=self.catalog_columns_per_table,
            )
            task_id = str(task.get("id", task.get("instance_id", "unknown")))
            question = task["question"]
            business_rule_domains = infer_business_rule_domains(task_id, question, schema_tables)
            domain_rules = render_domain_rules(
                business_rule_domains,
                fund_rules=fund_rules,
                bond_rules=bond_rules,
            )

            ps = Text2SQLProblemStatement(
                question=question,
                mode=task.get("mode", "sql"),
                reference_sql=task.get("sql_code", task.get("reference_sql", "")) or "",
                reference_python=task.get("python_code", task.get("reference_python", "")) or "",
                result_vars=list(task.get("result_vars", [])),
                reference_results=list(task.get("reference_results", [])),
                difficulty=task.get("difficulty", "unknown"),
                extra_fields={
                    "schema_path": str(self.schema_path.resolve()),
                    "schema_catalog": focused_schema_catalog or default_schema_catalog,
                    "focused_schema_catalog": focused_schema_catalog or default_schema_catalog,
                    "schema_table_index": schema_table_index,
                    "task_schema_tables": ", ".join(schema_tables) if schema_tables else "(not provided)",
                    "canonical_question": task.get("canonical_question", task["question"]),
                    "desk_style_paraphrases": task.get("desk_style_paraphrases", ""),
                    "task_spec": task.get("task_spec", ""),
                    "output_contract": task.get("output_contract", ""),
                    "evaluation_contract": task.get("evaluation_contract", ""),
                    "benchmark_title": task.get("benchmark_title", ""),
                    "reference_links": list(task.get("reference_links", [])),
                    "reference_artifact_paths": list(task.get("reference_artifact_paths", [])),
                    "reference_sidecar_paths": list(task.get("reference_sidecar_paths", [])),
                    "evaluation_kind": task.get("evaluation_kind", ""),
                    "reference_status": task.get("reference_status", ""),
                    "reference_error": task.get("reference_error", ""),
                    "result_dir": task.get("result_dir", ""),
                    "inputs": task.get("inputs", {}),
                    "strict_output_schema": bool(task.get("strict_output_schema", False)),
                    "single_numeric_output": task.get("single_numeric_output", False),
                    "column_order_matters": bool(task.get("column_order_matters", True)),
                    "comparison_rules": task.get("comparison_rules"),
                    "benchmark_source_path": str(self.path.resolve()),
                    "catalog_schema_path": str(self.catalog_schema_path.resolve()),
                    "business_metadata_path": str(self.business_metadata_path.resolve()) if self.business_metadata_path else "",
                    "selection_guidance_path": str(self.selection_guidance_path.resolve()) if self.selection_guidance_path else "",
                    "fund_rules_path": (
                        str(self.fund_rules_path.resolve()) if self.fund_rules_path and "fund" in business_rule_domains else ""
                    ),
                    "bond_rules_path": (
                        str(self.bond_rules_path.resolve()) if self.bond_rules_path and "bond" in business_rule_domains else ""
                    ),
                    "schema_columns_per_table": self.schema_columns_per_table,
                    "business_rule_domains": ", ".join(business_rule_domains) if business_rule_domains else "general",
                    "business_background": business_background,
                    "selection_guidance": selection_guidance,
                    "domain_rules": domain_rules,
                    "fund_rules": fund_rules if "fund" in business_rule_domains else "",
                    "bond_rules": bond_rules if "bond" in business_rule_domains else "",
                    "table_name_list": table_name_list,
                },
                id=task_id,
            )
            instances.append(
                BatchInstance(
                    env=EnvironmentConfig(deployment=self.deployment.model_copy(deep=True)),
                    problem_statement=ps,
                )
            )
        logger.info("Loaded %d Text2SQL instances from %s", len(instances), self.path)
        return _filter_batch_items(instances, filter_=self.filter, slice_=self.slice, shuffle=False)

    @property
    def id(self) -> str:
        return f"text2sql_{self.path.stem}"


BatchInstanceSourceConfig = (
    InstancesFromHuggingFace | InstancesFromFile | SWEBenchInstances
    | ExpertInstancesFromFile | SWESmithInstances | Text2SQLInstances
)
