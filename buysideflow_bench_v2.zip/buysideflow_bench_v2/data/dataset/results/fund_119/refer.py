#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[4]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from sweagent.text2sql.db_connector import query_to_dataframe

OUTPUT_COLUMNS = [
    "新基金经理名称",
    "任职日期",
    "前窗口",
    "后窗口",
    "前60日累计超额收益（%）",
    "后60日累计超额收益（%）",
    "是否改善",
]


def main() -> pd.DataFrame:
    sql_path = Path(__file__).with_name("refer.sql")
    output_path = Path(__file__).with_name("result.csv")
    sql = sql_path.read_text(encoding="utf-8")
    df = query_to_dataframe(sql, max_rows=0, timeout=600)
    if df is None:
        raise ValueError("SQL execution returned None")
    if df.empty and len(df.columns) == 0:
        df = pd.DataFrame(columns=OUTPUT_COLUMNS)
    df.to_csv(output_path, index=False, encoding="utf-8-sig", float_format="%.2f")
    print(df.to_string(index=False, float_format=lambda x: f"{x:.2f}") if not df.empty else "<empty result>")
    return df


if __name__ == "__main__":
    main()
